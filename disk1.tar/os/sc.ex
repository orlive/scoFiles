%s/\<init_stop\>/os_int_stop/g
%s/\<usage\>/os_usage/g
%s/\<init_dir\>/os_init_dir/g
%s/\<init\>/os_init/g
%s/\<wininit\>/os_wininit/g
%s/\<uninit\>/os_uninit/g
%s/\<refresh_all\>/os_refresh_all/g
%s/\<int_stop\>/os_int_stop/g
